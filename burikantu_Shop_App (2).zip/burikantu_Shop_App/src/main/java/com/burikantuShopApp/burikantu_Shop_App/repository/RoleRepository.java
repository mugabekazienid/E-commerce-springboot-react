package com.burikantuShopApp.burikantu_Shop_App.repository;


import com.burikantuShopApp.burikantu_Shop_App.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
