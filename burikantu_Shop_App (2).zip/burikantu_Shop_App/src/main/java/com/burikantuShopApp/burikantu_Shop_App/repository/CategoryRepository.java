package com.burikantuShopApp.burikantu_Shop_App.repository;

import com.burikantuShopApp.burikantu_Shop_App.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer> {



}
