package com.burikantuShopApp.burikantu_Shop_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BurikantuShopAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BurikantuShopAppApplication.class, args);
	}

}
