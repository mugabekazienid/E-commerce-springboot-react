package com.burikantuShopApp.burikantu_Shop_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurikantuShopAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
